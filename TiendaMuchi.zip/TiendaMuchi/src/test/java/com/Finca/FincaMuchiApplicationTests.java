package com.Finca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FincaMuchiApplicationTests {

	@Test
	void contextLoads() {
	}

}
