package com.Finca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FincaMuchiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FincaMuchiApplication.class, args);
	}

}
